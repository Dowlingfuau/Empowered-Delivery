window.charts = window.charts || {};

function destroyChart(id) 
{
    if (window.charts[id]) {
        window.charts[id].destroy();
        delete window.charts[id];
    }
}

window.createLineChart = (canvasId, labels, data, label) => 
{

    destroyChart(canvasId);

    const ctx = document.getElementById(canvasId);

    window.charts[canvasId] = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: label,
                data: data,
                borderWidth: 2,
                tension: 0.3,
                fill: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'nearest',
                intersect: false
            },
            scales: {
                y: {
                    min: 0,
                    max: 100
                }
            },
        }
    });
};

window.createMultiLineChart = (canvasId, labels, datasets) => 
    {

    destroyChart(canvasId);

    const ctx = document.getElementById(canvasId);

    const formattedDatasets = datasets.map(ds => ({
        label: ds.label,
        data: ds.data,
        borderColor: ds.borderColor,
        borderWidth: 2,
        tension: 0.3,
        fill: false
    }));

    window.charts[canvasId] = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: formattedDatasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'nearest',
                intersect: false
            },
            scales: {
                y: {
                    min: 0,
                    max: 100
                }
            },
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                },
               
            }
        }
    });
    window.clearChart = (canvasId) => 
    {
    if (window.charts[canvasId]) {
        window.charts[canvasId].destroy();
        delete window.charts[canvasId];
        }
    };
};
